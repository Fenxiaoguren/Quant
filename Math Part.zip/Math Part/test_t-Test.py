import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from scipy import stats

# One Sample t Test
TRD_Index = pd.read_table('TRD_Index_2.txt', sep = '\t')
Shindex = TRD_Index[TRD_Index.Indexcd == 1]
SHRet = Shindex.Retindex
# print(stats.ttest_1samp(SHRet, 0))  # return tvalue and pvalue

# Paired Sample t Test
SZindex = TRD_Index[TRD_Index.Indexcd == 399106]
SZRet = SZindex.Retindex
# print(stats.ttest_ind(SHRet, SZRet))  # return tvalue and pvalue

# Independent Sample t Test
print(stats.ttest_rel(SHRet, SZRet))  # return tvalue and pvalue


