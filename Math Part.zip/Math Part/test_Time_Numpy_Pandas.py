import calendar
import cmath
import math
import datetime
from dateutil.parser import parse
import time

import numpy as np
import pandas as pd

import pymysql
import matplotlib

class Assets():
    def __init__(self,id, price):
        self.id = id
        self.price = price

asset1 = Assets(1,1)
print(asset1.id)
print(asset1.price)

print(time.time())
print(time.localtime())
print(time.asctime())
print(time.localtime())
print(time.ctime())

print(parse('10'))

S = pd.Series([1,3,5,7,9],index=['a','b','c','d','e'])
print(S)
S['f'] = 11
print(S)

print(S[[1,3,4]])
