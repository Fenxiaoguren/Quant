import matplotlib.pyplot
import matplotlib.pyplot as plt
import pandas as pd

plt.rcParams['font.sans-serif'] = ['SimHei'] # 用来正常显示中文标签

ChinaBank = pd.read_csv('ChinaBank.csv',index_col='Date')
ChinaBank = ChinaBank.iloc[:, 1:]
ChinaBank.head()

ChinaBank.index = pd.to_datetime(ChinaBank.index)
Close = ChinaBank.Close
Open = ChinaBank.Open

plt.figure()
plt.plot(Close['2014'], color='r',label='收盘价', linestyle='solid')
plt.plot(Open['2014'], color='b',label='开盘价', linestyle='--')
plt.legend(loc='best')
plt.title('中国银行2014年开盘价/收盘价曲线',loc='center')
plt.xlabel('日期')
plt.ylabel('开盘价/收盘价')
plt.grid(True, which='major', axis='both')
plt.show()

plt.plot(Close['2015'], marker='o', label='收盘价')
plt.plot(Open['2015'], marker='*', label='开盘价')
plt.legend(loc='best')
plt.xlabel('日期')
plt.ylabel('价格')
plt.title('中国银行2015年开盘与收盘价曲线')
plt.grid(True, axis='both')
plt.show()

'''
matplotlib.pyplot.xlim(0,8) #(最小值，最大值)
matplotlib.pyplot.ylim(-1,1) #(最小值，最大值)

plt.plot([1,1,0,0,-1,0,1,1,-1])
plt.show()
'''



