import pandas as pd
import numpy as np
from matplotlib import pyplot as plt

# 读取数据
TRD_Index = pd.read_table('TRD_Index.txt', sep='\t')
# 获取上证综指数据，代码为“000001”
SHindex = TRD_Index[TRD_Index.Indexcd==1]
# print(SHindex.head(3))

# 获取深证综合指数数据，代码为“399106”
SZindex = TRD_Index[TRD_Index.Indexcd==399106]
# print(SZindex.head(3))

plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 显示符号
plt.scatter(SHindex.Retindex, SZindex.Retindex)
plt.title('上证指数与深证成指收益率的散点图')
plt.xlabel('上证综指收益率')
plt.ylabel('深证成指收益率')
plt.show()

# 相关系数求解
SZindex.index = SHindex.index
print(SZindex.Retindex.corr(SHindex.Retindex))

