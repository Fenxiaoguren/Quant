import pandas as pd
import matplotlib.pyplot as plt


returns = pd.read_csv('PythonQuant_cn/PythonQuant_cn/Python Quant Book/Python Quant Book/part 2/013/retdata.csv')
gsyh= returns.gsyh

print(gsyh.mean())
print(gsyh.median())
print(gsyh.mode())

print([returns.gsyh.quantile(i) for i in [0, 1]])

# Range,Mean Absolute Deviation, Variance&Standard Deviation
print([returns.gsyh.max()-returns.gsyh.min()])
print(returns.gsyh.mad())
print(returns.gsyh.var())
print(returns.gsyh.std())
