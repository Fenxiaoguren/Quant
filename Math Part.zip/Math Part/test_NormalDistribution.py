import numpy as np
import pandas as pd
import scipy
from scipy import stats

# 生成5个标准正态分布随机数
Norm = np.random.normal(size=100)
# print(Norm)
# print(stats.norm.pdf(Norm))  # 生成的正态分布随机数的密度值
# print(stats.norm.cdf(Norm))  # 生成的正态分布随机数的累计密度值

# VaR(Value at Risk)：
# 在一定概率水平（α%）下，某一金融资产或金融资产组合在未来特定一段时间内的最大可能损失
# P{Xt < -VaR} = α%；
# Xt：金融资产或金融资产组合在持有期Δt内的损失；
# 1-α%：VaR的置信水平

# 假设沪深300指数的日收益率序列服从正态分布，求当概率水平为5%的时候沪深300指数在2015年1月5日的VaR
HSRet300 = pd.read_csv('PythonQuant_cn/PythonQuant_cn/Python Quant Book/Python Quant Book/part 2/014/return300.csv')
ret = HSRet300.iloc[:,1]
HSRet300_RetMean = ret.mean()
HSRet300_RetVarience = ret.var()

# 查询累计密度值为5%的分位数
#  ppf():累计分布函数的逆函数（分位点函数，给出分位点返回对应的x值）
# **:此处意为方差开根号
print(stats.norm.ppf(0.05, HSRet300_RetMean, HSRet300_RetVarience**0.5))



