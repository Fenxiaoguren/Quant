import pandas as pd
import statsmodels.api as sm
import matplotlib.pyplot as plt
import scipy.stats as stats

TRD_Index = pd.read_table('TRD_Index_5.txt', sep='\t')
SHindex = TRD_Index[TRD_Index.Indexcd == 1]
SZindex = TRD_Index[TRD_Index.Indexcd == 399106]
SHRet = SHindex.Retindex
SZRet = SZindex.Retindex
SZRet.index = SHRet.index

#   Y = α + β * X + ε
model = sm.OLS(SHRet, sm.add_constant((SZRet))).fit()
#   print(model.summary())
#
#   1.  α = -0.0003,    p = 0.081 > 0.05: reject(α = 0)
#   2.  β = 0.7603,     p = 0 < 0.05: accept (β = 0.7603)
#   SHRet = -0 + 0.7603 * SZRet + ε, according to 1. and 2.
#
#   print(model.fittedvalues[:5])

plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 显示符号

#   1.线性
plt.scatter(model.fittedvalues, model.resid)
plt.xlabel('拟合值')
plt.ylabel('残差')
#   plt.show()
#   弱因变量与自变量线性相关，残差值应该和拟合值没有任何的系统关联，呈现出围绕着0随机分布的状态。
#   plt.show()很好地证明假设基本成立

#   2.正态
#   当因变量成正态分布时，模型的残差项应该是一个均值为0的正态分布。
#   正态Q-Q图是在正态分布对应的值下，标准化残差的概率图
#   若满足正态性假设，图上的点英国落在一条直线上；反之则违背了正态性假设
sm.qqplot(model.resid_pearson, stats.norm, line='45')
#   plt.show()
#   残差在两端出现了较为严重的偏离；数据可能并不满足正态性的假设（金融数据特征：尖峰厚尾）

#   3.同方差性
#   若满足方差不变假设，在位置尺度图（Scale-Location Plot）上，各点分布应该呈现出一条【水平的、宽度样子hi的条带曲线】
plt.scatter(model.fittedvalues, model.resid_pearson**0.5)
plt.xlabel('拟合值')
plt.ylabel('标准化残差的平方根')
#   plt.show()

