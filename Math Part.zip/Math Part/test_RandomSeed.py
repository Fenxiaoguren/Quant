import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from scipy import stats
from numpy import cumsum
from matplotlib.pyplot import subplots
from matplotlib.pyplot import subplot
from matplotlib.pyplot import plot

plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 显示符号

RandomNumber = np.random.choice([1, 2, 3, 4, 5],
                                size = 100, replace=True,
                                p=[0.1, 0.1, 0.3, 0.3, 0.2])
print(pd.Series(RandomNumber).value_counts())

HSRet300 = pd.read_csv('PythonQuant_cn/PythonQuant_cn/Python Quant Book/Python Quant Book/part 2/014/return300.csv')
print(HSRet300.head(n=2))

density = stats.kde.gaussian_kde(HSRet300.iloc[:,1])
bins = np.arange(-5,5,0.02)  # 设置分割区间

plt.subplot(211)
plt.plot(bins, density(bins))
plt.title('沪深300收益率序列的概率密度曲线图')
plt.show()

plt.subplot(212)
plt.plot(bins, density(bins).cumsum())
plt.title('沪深300收益率序列的累积分布函数图')
plt.show()
