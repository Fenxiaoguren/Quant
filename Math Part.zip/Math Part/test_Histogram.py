import pandas as pd
import matplotlib.pyplot as plt


returns = pd.read_csv('PythonQuant_cn/PythonQuant_cn/Python Quant Book/Python Quant Book/part 2/013/retdata.csv')
gsyh= returns.gsyh

print(plt.hist(gsyh))
plt.show()