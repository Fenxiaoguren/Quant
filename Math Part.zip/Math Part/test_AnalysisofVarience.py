#   方差分析研究问题：两个或多个不同的水平下，反应变量是如何取值的
#   水平：因子变量的取值    反应变量：被影响的变量
#
#   方差分析的研究对象：各个组别反应变量均值之间可能存在的差异；组别的划分是以因子变量为依据的，借助方差来观察均值是否相同
#   如果反应变量在不同组别中的均值是相同的，则认为分组所依据的因子变量对反应变量没有影响
#
#   方差分析：从反应变量的方差入手，研究诸多因子中，哪些因子对观测变量有显著影响。
#
#   方差分析无法预测，但可分析和比较各组之间的差异。
#
#   存在干扰因素（Confounding Factor）:需要加入其它变量以控制干扰因素
#   1.随机区组设计（Randomized Block Design）：加入因子变量
#   2.协方差分析（Analysis of Covariance, ANCOVA）：加入连续变量

#   行业对股票收益率的影响

import pandas as pd
import statsmodels.stats.anova as anova
from statsmodels.formula.api import ols

#   One Way ANOVA
year_return = pd.read_csv('TRD_Year_3.csv', encoding='gbk')
#   print(year_return.head())

#   AoV
model = ols('Return ~ C(Industry)',
            data=year_return.dropna()).fit()
table1 = anova.anova_lm(model)
#   print(table1)
#   pvalue = 4.382045e-28<0.05, reject Null Hypothesis,
#   which means that stocks in different industries have different year_return (in 2014)
#   Industry is a key factor that influece stock's year_return

#   Factorial ANOVA
#   educatn & married -> earnings
PSID = pd.read_csv('PSID_4.csv')
#   print(PSID.head())
#   establish model
model = ols('earnings ~ C(married) + C(educatn)',
            data=PSID.dropna()).fit()
table2 = anova.anova_lm(model)
#   print(table2)

#   whether one influence is related to another
model = ols('earnings ~ C(married) * C(educatn)',
            data=PSID.dropna()).fit()
table3 = anova.anova_lm(model)
#   print(table3)
#   pvalue(C(married):C(educatn)) = 7.352239e-01 ≈ 0.7 ＞ 0.05
#   isn't related to. independent
