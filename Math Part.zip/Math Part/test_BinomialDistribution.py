import numpy as np
import pandas as pd
from scipy import stats

print(np.random.binomial(100, 0.5, 20))

#  投100次硬币，有20次正面向上的概率是多少？
print(stats.binom.pmf(20, 100, 0.5))

#  投100次硬币，有小于20次正面向上的概率是多少？
print(stats.binom.cdf(20, 100, 0.5))

#  估计接下来10天中沪深300指数有6天上涨的概率

#  1.获取2014年沪深300的收益率数据
HSRet300 = pd.read_csv('PythonQuant_cn/PythonQuant_cn/Python Quant Book/Python Quant Book/part 2/014/return300.csv')
ret = HSRet300.iloc[:,1]
print(ret.head(n=3))

#  2.估算沪深300上涨的概率p
p = len(ret[ret>0])/len(ret)
print(p)

# 3.估计十天中有6天上涨的概率
prob = stats.binom.pmf(6, 10, p) # pmf:至少6天上涨
print(prob)
