#   多元线性回归分析中，各个自变量间不可共线
#   Yi = β0 + β1 * X1 + ... + βk * Xk + εi

#   Price Level -> GDP

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import scipy.stats
import statsmodels.api as sm

plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 显示符号

penn = pd.read_excel('Penn World Table.xlsx', 2)
#   print(penn.head(3))

#   examine corr between each factor
#   print(penn.iloc[:, -6:].corr())
#   remove pl_c and pl_k according to the corr()

model = sm.OLS(np.log(penn.rgdpe), sm.add_constant(penn.iloc[:, -5:-1])).fit()
#   print(model.summary())
#   log(rgdpe_i) = 8.3558 - 1.1290 * pl_i + 1.5452 * pl_g - 3.0228 * pl_x + 6.0596 * pl_m
