import numpy as np
import pandas as pd
from scipy import stats
from matplotlib import pyplot as plt

plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 显示符号

Shindex = pd.read_csv('TRD_Index_1.csv')
# print(Shindex.head(3))

Retindex = Shindex.Retindex
# print
# print(Retindex.hist())

mu = Retindex.mean()
sigma = Retindex.std()
plt.plot(np.arange(-0.06, 0.062, 0.002),
         stats.norm.pdf(np.arange(-0.06, 0.062, 0.002),
         mu, sigma))
# plt.show()

# interval estimation
print(stats.t.interval(0.95, len(Retindex)-1,
                 mu, stats.sem(Retindex)))



