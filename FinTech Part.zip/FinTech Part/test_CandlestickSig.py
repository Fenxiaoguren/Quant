import matplotlib
import matplotlib.pyplot as plt
import pandas as pd
import candle
from mpl_finance import candlestick_ohlc
from matplotlib.dates import DateFormatter, WeekdayLocator, DayLocator, MONDAY, date2num
from datetime import datetime

#   plt
plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 显示符号
matplotlib.use('Tkagg')

ssec2012 = pd.read_csv('SSEC2012.csv')
ssec2012.index = ssec2012.iloc[:, 1]
ssec2012.index = pd.to_datetime(ssec2012.index, format='%Y-%m-%d')
ssec2012 = ssec2012.iloc[:, 2:]  #  get off the redundant data
#   print(ssec2012.head())
#   print(ssec2012.iloc[-3:, :])

Close = ssec2012.Close
Open = ssec2012.Open

#   clop:   close - open
ClOp = Close - Open
#   print(ClOp.describe())
Shape = [0, 0, 0]
lag1ClOp = ClOp.shift(1)
lag2ClOp = ClOp.shift(2)
for i in range(3, len(ClOp), 1):
    if all([lag2ClOp[i] < -11, abs(lag1ClOp[i]) < 2,
            ClOp[i] > 6, abs(ClOp[i]) > abs(lag2ClOp[i] * 0.5)]):
        Shape.append(1)
    else:
        Shape.append(0)

'''
#   search for the first position that Shape.index == 1
try:
    print(Shape.index(1))
except:
    print('1 is not in Shape')
else:
    print()
'''

#   Sig1:   Doji:   Between and below two red real bodies or two green real bodies
lagOpen = Open.shift(1)
lagClose = Close.shift(1)
lag2Close = Close.shift(2)

#   extract Doji:
Doji = [0, 0, 0]
for i in range(3, len(Open), 1):
    if all([lagOpen[i] < Open[i], lagOpen[i] < lag2Close[i],
           lagClose[i] < Open[i], lagClose[i] < lag2Close[i]]):
        Doji.append(1)
    else:
        Doji.append(0)

#   print(Doji.count(1))

#   Sig1.1: Morning Star
#   define downtrend
ret = Close / Close.shift(1) - 1
lag1ret = ret.shift(1)
lag2ret = ret.shift(2)
Trend = [0, 0, 0]
for i in range(3, len(ret)):
    if all([lag1ret[i] < 0, lag2ret[i] < 0]):
        Trend.append(1)
    else:
        Trend.append(0)

#   find the morning star
StarSig = []
for i in range(len(Trend)):
    if all([Shape[i] == 1, Doji[i] == 1, Trend[i] == 1]):
        StarSig.append(1)
    else:
        StarSig.append(0)

for i in range(len(StarSig)):
    if StarSig[i] == 1:
        print(ssec2012.index[i])    #   2012-09-06

ssec201209 = ssec2012['2012-08-21': '2012-09-30']
candle.candlePlot(ssec201209,
                  title='The daily K-line chart of the Shanghai Composite Index in September 2012')
#   plt.show()

#   Sig2:   Dark Cloud Cover
ssec2011 = pd.read_csv('SSEC2011.csv')
ssec2011.index = ssec2011.iloc[:, 1]
ssec2011.index = pd.to_datetime(ssec2011.index, format='%Y-%m-%d')
ssec2011 = ssec2011.iloc[:, 2:]

Close11 = ssec2011.Close
Open11 = ssec2011.Open

lagClose11 = Close11.shift(1)
lagOpen11 = Open11.shift(1)
Cloud = pd.Series(0, index=Close11.index)
for i in range(1, len(Close11)):
    if all([Close11[i] < Open11[i], lagClose11[i] > lagOpen11[i],
            Open11[i] > lagClose11[i], Close11[i] < 0.5 * (lagClose11[i] + lagOpen11[i]),
            Close11[i] > lagOpen11[i]]):
        Cloud[i] = 1

#   define uptrend
Trend = pd.Series(0, index=Close11.index)
for i in range(2, len(Close11)):
    if (Close11[i - 1] > Close11[i - 2] > Close11[i - 3]):
        Trend[i] = 1

darkCloud = Cloud + Trend
#   print(darkCloud[darkCloud == 2])
#   2015-05-19
#   2015-08-16

ssec201105 = ssec2011['2011-05-01': '2011-05-31']
candle.candlePlot(ssec201105, title='The daily K-line chart of the Shanghai Composite Index in May 2011')
ssec201108 = ssec2011['2011-08-01': '2011-08-30']
candle.candlePlot(ssec201108, title='The daily K-line chart of the Shanghai Composite Index in August 2011')

plt.show()



