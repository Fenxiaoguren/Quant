import candle
import momentum
import plotplus
import pandas as pd
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from momentum import momentum

Vanke = pd.read_csv('Vanke.csv')
Vanke.index = Vanke.iloc[:, 1]
Vanke.index = pd.to_datetime(Vanke.index, format='%Y-%m-%d')
Vanke = Vanke.iloc[:, 2:]
#   print(Vanke.head(2))

Close = Vanke.Close
#   print(Close.describe())

#   lag 35 periods
momen35 = momentum(Close, 35)
#   print(momen35.head())

#   when momen35 < 0, sell vanke, signal == -1;
#   when momen35 > 0, buy vanke, signal == 1;
signal = []
for i in momen35:
    if i > 0:
        signal.append(1)
    else:
        signal.append(-1)

signal = pd.Series(signal, index=momen35.index)
#   print(signal.head())

#   calculate the rate of return
tradeSig = signal.shift(1)
ret = Close / Close.shift(1) - 1
Mom35Ret = (ret * tradeSig).dropna()
#   print(Mom35Ret[:5])

#   Model Evaluation
Mom35Ret[Mom35Ret == 0] = 0
win = Mom35Ret[Mom35Ret > 0]
winrate = len(win) / len(Mom35Ret[Mom35Ret != 0])
#   print(winrate)  #   0.5211267605633803

#   plot
'''
plt.subplot(211)
plt.plot(ret[-len(Mom35Ret):], 'b')
plt.ylabel('return')
plt.ylim(-0.13, 0.1)
plt.title('Rate of Return')
plt.subplot(212)
plt.plot(Mom35Ret, 'r')
plt.ylabel('Mom35Ret')
plt.ylim(-0.13, 0.1)
plt.title('Momentum Rate of Return')
'''
#   plt.show()

'''
loss = -Mom35Ret[Mom35Ret < 0]
plt.subplot(211)
win.hist()
plt.title('Earnings Histogram')
plt.subplot(212)
loss.hist()
plt.title('Loss Histogram')
'''
#   plt.show()

#   although accuracy is over 0.5, loss's return is higher than earning's return

