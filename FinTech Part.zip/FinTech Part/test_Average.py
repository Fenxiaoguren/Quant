import candle
import pandas as pd
import numpy as np
import matplotlib
import plotplus
import matplotlib.pyplot as plt
import Average as ma
from Average import smaCal, wmaCal, ewmaCal

ChinaBank = pd.read_csv('ChinaBank.csv')
ChinaBank.index = ChinaBank.iloc[:, 1]
ChinaBank.index = pd.to_datetime(ChinaBank.index, format='%Y-%m-%d')
ChinaBank = ChinaBank.iloc[:, 2:]

CBClose = ChinaBank.Close
#   print(CBClose.describe())

#   Close Price in 2015, time period == 10 days
Close15 = CBClose['2015']

Sma10 = smaCal(Close15, 10)
#   print(Sma10.tail())

weight = np.array(range(1, 11)) / sum(range(1, 11))
Wma10 = wmaCal(Close15, weight)
#   print(Wma10.tail())

expo = 2 / (len(Close15) + 1)   #   +1 prevents error
Ema10 = ewmaCal(Close15, 10, expo)
#   print(Ema10.tail())

#   plot
'''
plt.plot(Close15[10:], label='Close', color='k')
plt.plot(Sma10[10:], label='Sma10', color='r', linestyle='dashed')
plt.plot(Wma10[10:], label='Wma10', color='b', linestyle=':')
plt.plot(Ema10[10:], label='Ema10', color='g', linestyle='-.')
plt.title('Bank of China Price Moving Average')
plt.ylim(3.5, 5.5)
plt.legend()
plt.show()
'''

#   Close Price in 2015, time period == 5 days
'''
Sma5 = smaCal(Close15, 5)
Sma30 = smaCal(Close15, 30)
plt.plot(Close15[30:], label='Close', color='k')
plt.plot(Sma5[30:], label='Sma5', color='r', linestyle='dashed')
plt.plot(Sma30[30:], label='Sma30', color='r', linestyle=':')
plt.title('Bank of China Long-Term and Short-Term Price Moving Average')
plt.ylim(3.5, 5.5)
plt.legend()
plt.show()
'''

#   Moving Average Strategy
#   1.  SMA
#       1.1  Buy in when stock price goes up through the moving average line,
#            as the line serves as a resistance line.
#       1.2  Sell out when stock price goes down through the moving average line,
#            as the line serves as a support line.

#   Test:   10 days, from 2014 to April 2015
CBSma10 = smaCal(CBClose, 10)
SmaSignal = pd.Series(0, index=CBClose.index)
for i in range(10, len(CBClose)):
    if all([CBClose[i] > CBSma10[i], CBClose[i - 1] < CBSma10[i - 1]]):
        SmaSignal[i] = 1
    elif all([CBClose[i] < CBSma10[i], CBClose[i - 1] > CBSma10[i - 1]]):
        SmaSignal[i] = -1
SmaTrade = SmaSignal.shift(1).dropna()
#   print(SmaTrade.head(n=3))

SmaBuy = SmaTrade[SmaTrade == 1]
#   print(SmaBuy.head(n=3))
SmaSell = SmaTrade[SmaTrade == -1]
#   print(SmaSell.head(n=3))

#   Single-Period Rate of Return
CBRet = CBClose / CBClose.shift(1) - 1
SmaRet = (CBRet * SmaTrade).dropna()

cumStock = np.cumprod(1 + CBRet[SmaRet.index[0]:]) - 1
cumTrade = np.cumprod(1 + SmaRet) - 1
cumdata = pd.DataFrame({'cumTrade': cumTrade, 'cumStock': cumStock})
#   print(cumdata.iloc[-6:, :])

#   plot SMA
'''
plt.plot(cumStock, LABEL="cumStock", color='k')
plt.plot(cumTrade, LABEL="cumTrade", color='r', linestyle=':')
plt.title("Cumulative Rate of Return of both Stock and SMA Strategy")
plt.legend()
plt.show()  #   MA Strategy is not ok in this case
'''

SmaRet[SmaRet == (-0)] = 0
smaWinrate = len(SmaRet[SmaRet > 0]) / len(SmaRet[SmaRet != 0])
#   print(smaWinrate)   #   accuracy

#   2.  DMA (Double MA)
#   2.1 Get a short-period MA and a long-period MA
#   2.2 Buy in when the short-period MA goes up through the long-period MA
#   2.3 Sell out when the short-period MA goes down through the long-period MA

#   short-period MA:    sma5
#   long-period MA:     sma30

Ssma5 = smaCal(CBClose, 5)
Lsma30 = smaCal(CBClose, 30)
SLSignal = pd.Series(0, index=Lsma30.index)
for i in range(1, len(Lsma30)):
    if all([Ssma5[i] > Lsma30[i], Ssma5[i - 1] < Lsma30[i - 1]]):
        SLSignal[i] = 1
    elif all([Ssma5[i] < Lsma30[i], Ssma5[i - 1] > Lsma30[i - 1]]):
        SLSignal[i] = -1

#   print(SLSignal[SLSignal == 1])
#   print(SLSignal[SLSignal == -1])
SLTrade = SLSignal.shift(1)
CBRet = CBClose / CBClose.shift(1) - 1

# win-rate == predict accuracy

#   Long-Only Strategy based on DMA
Long = pd.Series(0, index=Lsma30.index)
Long[SLTrade == 1] = 1
LongRet = (Long * CBRet).dropna()
winLrate = len(LongRet[LongRet > 0]) / len(LongRet[LongRet != 0])
#   print(winLrate)

#   Short-Only Strategy based on DMA
Short = pd.Series(0, index=Lsma30.index)
Short[SLTrade == -1] = -1
ShortRet = (Short * CBRet).dropna()
winSrate = len(ShortRet[ShortRet > 0]) / len(ShortRet[ShortRet != 0])
#   print(winSrate)

#   Long-Short Strategy based on DMA
SLtradeRet = (SLTrade * CBRet).dropna()
winRate = len(SLtradeRet[SLtradeRet > 0]) / len(SLtradeRet[SLtradeRet != 0])
#   print(winRate)

cumLong = np.cumprod(1 + LongRet) - 1
cumShort = np.cumprod(1 + ShortRet) - 1
cumSLtrade = np.cumprod(1 + SLtradeRet) - 1

#   plot and compare three DMAs
'''
plt.plot(cumSLtrade, label='cumSLtrade', color='k')
plt.plot(cumLong, label='cumLongtrade', color='b', linestyle='dashed')
plt.plot(cumShort, label='cumShorttrade', color='r', linestyle=':')
plt.title('Cumulative Rate of Returns based on Long-Short Moving Average Strategies')
plt.legend(loc='best')
plt.show()
'''

#   3.  MACD (Moving Average Convergence / Divergence)
#   3.1 DIF = EMA(Close, period=12) - EMA(Close, period=26)
DIF = ewmaCal(CBClose, 12, 2 / (1 + 12)) - ewmaCal(CBClose, 26, 2 / (1 + 26))
#   print(DIF.tail(n=3))

#   3.2 DEA = EMA(DIF, period=9)
DEA = ewmaCal(DIF, 9, 2 / (1 + 9))
#   print(DEA.tail())

#   MACD = DIF - DEA
MACD = DIF - DEA
#   print(MACD.tail())

#   plot DIF, DEA, and MACD
'''
plt.subplot(211)
plt.plot(DIF['2015'], label='DIF', color='k')
plt.plot(DEA['2015'], label='DEA', color='b', linestyle='dashed')
plt.title('DIF and DEA')
plt.legend(loc='best')
plt.subplot(212)
plt.bar(x=MACD['2015'].index, height=MACD['2015'], label='MACD', color='r')
plt.legend()
plt.show()
'''

#   test in ChinaBank dataset
macddata = pd.DataFrame()
macddata['DIF'] = DIF['2015']
macddata['DEA'] = DEA['2015']
macddata['MACD'] = MACD['2015']
#   print(macddata)
#   print(ChinaBank['2015'])
'''
candle.candleLinePlots(ChinaBank['2015'], candleTitle='Daily K-line Chart of ChinaBank in 2015',
                  splitFigures=True, Data=macddata, ylabel='MACD')
#   u need another plt functions in order to draw a png of MACD.
'''

macdSignal = pd.Series(0, index=DIF.index)
for i in range(1, len(DIF)):
    #   if DIF > 0, DEA > 0, DIF goes up through DEA, then buy in
    if all([DIF[i] > DEA[i] > 0.0, DIF[i - 1] < DEA[i - 1]]):
        macdSignal[i] = 1
    #   if DIF < 0, DEA < 0, DIF goes down through DEA, then sell out
    elif all([DIF[i] < DEA[i] < 0.0, DIF[i - 1] > DEA[i - 1]]):
        macdSignal[i] = -1
#   print(macdSignal.tail())

#   merge 3 strategies together
AllSignal = SmaSignal + SLSignal + macdSignal
#   actually ALLSignal = alpha * SmaSignal + beta * SLSignal + theta * macdSignal
#   here is ALLSignal(1, 1, 1)
for i in AllSignal.index:
    if AllSignal[i] > 1:
        AllSignal[i] = 1
    elif AllSignal[i] < -1:
        AllSignal[i] = -1
    else:
        AllSignal[i] = 0

#   print(ALLSignal[ALLSignal == 1])
#   print(ALLSignal[ALLSignal == -1])
tradSig = AllSignal.shift(1).dropna()
Close = CBClose[-len(tradSig):]
asset = pd.Series(0.0, index=Close.index)
cash = pd.Series(0.0, index=CBClose.index)     #    It is the cbclose.index instead of close.
share = pd.Series(0.0, index=CBClose.index)     #    It is the cbclose.index instead of close.
'''
entry = 3
cash[:entry] = 20000
while entry < len(CBClose):
    cash[entry] = cash[entry - 1]
    if all([CBClose[entry - 1] >= CBClose[entry - 2],
            CBClose[entry - 2] >= CBClose[entry - 3],
            ALLSignal[entry - 1] != -1]):
        share[entry] = 1000
        cash[entry] = cash[entry] - 1000 * CBClose[entry]
        break
    entry += 1

i = entry + 1
while i < len(tradSig):
    cash[i] = cash[i - 1]
    share[i] = share[i - 1]
    if tradSig[i] == 1:
        share[i] = share[i] + 3000
        cash[i] = cash[i] - 3000 * CBClose[i]

    if all([tradSig[i] == -1, share[i] >= 1000]):
        share[i] = share[i] - 1000
        cash[i] = cash[i] + 1000 * CBClose[i]
    i += 1

asset = cash + share * CBClose

plt.subplot(411)
plt.title('Moving Average Strategy: ChinaBank from 2014 to 2015(first half)')
plt.plot(CBClose, color='b')
plt.ylabel('Price')
plt.subplot(412)
plt.ylabel('Share')
plt.ylim(0, max(share) + 1000)

plt.subplot(413)
plt.plot(asset, label='asset', color='r')
plt.ylabel('Asset')
plt.ylim(min(asset)-5000, max(asset)+5000)
plt.subplot(414)
plt.plot(cash, label='cash', color='g')
plt.ylabel('Cash')
plt.ylim(0, max(cash) + 5000)
plt.show()

TradeReturn = (asset[-1] / 20000) / 20000
print(TradeReturn)
'''
''''''
#当价格连续两天上升且交易信号没有显示卖出时，
#第一次开账户持有股票
entry=3
cash[:entry]=20000
while entry<len(CBClose):
    cash[entry]=cash[entry-1]
    if all([CBClose[entry-1]>=CBClose[entry-2],\
            CBClose[entry-2]>=CBClose[entry-3],\
            AllSignal[entry-1]!=-1]):
        share[entry]=1000
        cash[entry]= cash[entry]-1000*CBClose[entry]
        break
    entry+=1

#根据signal买卖股票
i=entry+1
while i<len(tradSig):
    cash[i]=cash[i-1]
    share[i]=share[i-1]
    flag=1
    if tradSig[i]==1:
        share[i]= share[i]+3000
        cash[i]=cash[i]-3000*CBClose[i]

    if all([tradSig[i]==-1,share[i]>0]):
        share[i]= share[i]-1000
        cash[i]=cash[i]+1000*CBClose[i]
    i+=1

asset=cash+share*CBClose

plt.subplot(411)
plt.title("2014-2015年上:中国银行均线交易账户")
plt.plot(CBClose, color='b')
plt.ylabel("Price")
plt.subplot(412)
plt.plot(share, color='b')
plt.ylabel("Share")
plt.ylim(0,max(share)+1000)

plt.subplot(413)
plt.plot(asset,label="asset",color='r')
plt.ylabel("Asset")
plt.ylim(min(asset)-5000, max(asset)+5000)

plt.subplot(414)
plt.plot(cash, label="cash",color='g')
plt.ylabel("Cash")
plt.ylim(0,max(cash)+5000)

plt.show()

TradeReturn=(asset[-1]-20000)/20000
print(TradeReturn)

















