import matplotlib
matplotlib.use('Tkagg')
import matplotlib.pyplot as plt


#   plt
plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 显示符号
matplotlib.use('Tkagg')


