import  pandas as pd
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import candle
import plotplus
import ffn
from KDJ import *

#   Prevent Error:
#   Matplotlib is currently using agg, which is a non-GUI backend, so cannot show the figure.
matplotlib.use('Tkagg')

GSPC = pd.read_csv('GSPC.csv', index_col='Date')
GSPC = GSPC.iloc[:, 1:]
GSPC.index = pd.to_datetime(GSPC.index)
#   print(GSPC.head())

close = GSPC.Close
high = GSPC.High
low = GSPC.Low

date = close.index.to_series()
ndate = len(date)
periodHigh = pd.Series(np.zeros(ndate - 8), index=date.index[8:])
periodLow = pd.Series(np.zeros(ndate - 8), index=date.index[8:])
RSV = pd.Series(np.zeros(ndate - 8), index=date.index[8:])

#   for 9 days
for j in range(8, ndate):
    period = date[j - 8: j + 1]
    i = date[j]
    periodHigh[i] = high[period].max()
    periodLow[i] = low[period].min()
    RSV[i] = 100 * (close[i] - periodLow[i]) / (periodHigh[i] - periodLow[i])
    periodHigh.name = 'periodHigh'
    periodLow.name = 'periodLow'
    RSV.name = 'RSV'

#   print(RSV.head())
#   print(RSV.describe())
close1 = close['2015']
RSV1 = RSV['2015']
C1_RSV = pd.DataFrame([close1, RSV1]).transpose()
''''
C1_RSV.plot(subplots=True, title='Raw Stochastic Value')
plt.show()
'''

GSPC2015 = GSPC['2015-01-01':'2015-12-31']
'''
candle.candlePlot(GSPC2015, 'K-Line of S&P 500 Index in 2015')
plt.show()
'''

#   import K-value and D-value to solve the problem of high volatility of RSV
#   K_0 == D_0 == 50
#   weight: w1 = 2 / 3, w2 = 1 / 3

RSV1 = pd.Series([50, 50], index=date[6: 8]).append(RSV)
RSV1.name = 'RSV'
#   print(RSV1.head())

KValue = pd.Series(0.0, index=RSV1.index)
KValue[0] = 50
for i in range(1, len(RSV1)):
    KValue[i] = 2 / 3 * KValue[i - 1] + RSV1[i] / 3
KValue.name = 'KValue'
#   print(KValue.head())

DValue = pd.Series(0.0, index=RSV1.index)
DValue[0] = 50
for i in range(1, len(RSV1)):
    DValue[i] = 2 / 3 * DValue[i - 1] + KValue[i] / 3
DValue.name = 'DValue'
#   print(DValue.head())

KValue = KValue[1:]
DValue = DValue[1:]
'''
plt.subplot(211)
plt.title('Close Price of S&P 500 in 2015')
plt.plot(close['2015'])
plt.subplot(212)
plt.title('RSV and K&D Line of S&P 500 in 2015')
plt.plot(RSV['2015'])
plt.plot(KValue['2015'], linestyle='dashed')
plt.plot(DValue['2015'], linestyle='-.')
plt.show()
'''

#   J-value
#   let the parameters be 3 and 2
JValue = 3 * KValue - 2 * DValue
JValue.name = 'JValue'
#   print(JValue.head())

'''
plt.subplot(211)
plt.title('Close Price of S&P 500 in 2015')
plt.plot(close['2015'])
plt.subplot(212)
plt.title('RSV and K&D Line of S&P 500 in 2015')
plt.plot(RSV['2015'])
plt.plot(KValue['2015'], linestyle='dashed')
plt.plot(DValue['2015'], linestyle='-.')
plt.plot(JValue['2015'], linestyle='--')
plt.legend(loc='best')
plt.show()
'''

#   Strategy    1:  KD
#   sell out:   signal = -1 when K > 85 or D > 80
#   buy in:     signal = +1 when K < 20 or D <20

KSignal = KValue.apply(lambda  x: -1 if x > 85 else 1 if x < 20 else 0)
DSignal = DValue.apply(lambda  x: -1 if x > 80 else 1 if x < 20 else 0)
KDSignal = KSignal + DSignal
KDSignal.name = 'KDSignal'

#    use '[] ==' instead of '[]='
KDSignal[KDSignal >= 1] == 1
KDSignal[KDSignal <= -1] == -1
#   print(KDSignal.head(n=3))
#   print(KDSignal[KDSignal == 1].head(n=3))    #    use '[] ==' instead of '[]='

KDtrade = trade(KDSignal, close)
KDtrade.rename(columns={'ret': 'Ret',
                        'tradeRet': 'KDtradeRet'},
               inplace=True)
#   print(KDtrade.head())

#   print(backtest(KDtrade.Ret, KDtrade.KDtradeRet))
'''
                        Ret  KDtradeRet
win rate           0.549080    0.490566
annualized return  0.108128    0.017613
sharpe ratio       0.060163    0.017315
maximum drawdown  -0.074015   -0.097439
'''

cumRets1 = (1 + KDtrade).cumprod()
'''
plt.plot(cumRets1.Ret, label='Ret')
plt.plot(cumRets1.KDtradeRet, '--', label='KDtradeRet')
plt.title('Performance of KD-Strategy')
plt.legend(loc='best')
plt.show()
'''

#   Strategy    2:  KDJ
#   buy in:   signal = +1 when J > 100
#   sell out:     signal = -1 when K < 0
JSignal = JValue.apply(lambda x: -1 if x > 100 else 1 if x < 0 else 0)
KDJSignal = KSignal + DSignal + JSignal
KDJSignal = KDJSignal.apply(lambda x: 1 if x >=2 else -1 if x <= -2 else 0)

KDJtrade = trade(KDJSignal, close)
KDJtrade.rename(columns={'ret': 'Ret',
                         'tradeRet': 'KDJtradeRet'},
                inplace=True)
#   print(backtest(KDJtrade.Ret, KDJtrade.KDJtradeRet))
'''
                        Ret  KDJtradeRet
win rate           0.549080     0.506024
annualized return  0.108128     0.005666
sharpe ratio       0.060163     0.009630
maximum drawdown  -0.074015    -0.052597
'''

KDJCumRet = (1 + KDJtrade).cumprod()

'''
plt.plot(KDJCumRet.Ret, label='Ret')
plt.plot(KDJCumRet.KDJtradeRet, '--', label='KDJtradeRet')
plt.title('Performance of KDJ-Strategy')
plt.show()
'''

#   Strategy    3:  Golden Cross & Death Cross
#   buy in:   signal = +1 when K-Line goes up through the D-Line
#   sell out:     signal = -1 when K-Line goes down through the D-Line

KDupbreak = upbreak(KValue, DValue) * 1
KDdownbreak = downbreak(KValue, DValue) * 1
#   print(KDupbreak[KDupbreak == 1].head())
#   print(KDdownbreak[KDdownbreak == 1].head())

close = close['2014-01-14':]
difclose = close.diff()

prctrend = 2 * (difclose[1:] >= 0) - 1
#   print(prctrend.head())

#   I think the original codes are not readable, since they are not dual
#   KDupSig = (KDupbreak[1:] + prctrend) == 2
KDupSig = pd.Series(np.all([KDupbreak[1:] == 1, prctrend == 1],
                           axis=0), index=prctrend.index)
KDdownSig = pd.Series(np.all([KDdownbreak[1:] == 1, prctrend == -1],
                           axis=0), index=prctrend.index)
#   print(KDupSig.head())
#   print(KDdownSig.head())

#   there are errors when break = KDupSig - KDdownSig
#   minus is not supported
breakSig = KDupSig * 1 + KDdownSig * (-1)
breakSig.name = 'breakSig'
#   print(breakSig.head())

KDbreak = trade(breakSig, close)
KDbreak.rename(columns={'ret': 'Ret',
                        'tradeRet': 'KDbreakRet'},
               inplace=True)
#   print(KDbreak.head())

#   print(backtest(KDbreak.Ret, KDbreak.KDbreakRet))
'''
                        Ret  KDbreakRet
win rate           0.546296    0.433962
annualized return  0.095568   -0.024988
sharpe ratio       0.053920   -0.034377
maximum drawdown  -0.074015   -0.086469
'''

'''
KDbreakRet = (1 + KDbreak).cumprod()
plt.plot(KDbreakRet.Ret, label='Ret')
plt.plot(KDbreakRet.KDbreakRet, '--', label='KDbreakRet')
plt.title('Performance of KD & Cross-Strategy')
plt.legend(loc='best')
plt.show()
'''







