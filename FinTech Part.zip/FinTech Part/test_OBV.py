import pandas as pd
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import mpl_finance
import candle
import plotplus
import Average
from Average import smaCal
import ffn
from OBV import *

matplotlib.use('Tkagg')

TsingTao = pd.read_csv('TsingTao.csv', index_col='Date')
TsingTao.index = pd.to_datetime(TsingTao.index)
TsingTao.Volume = TsingTao.Volume.replace(0, np.nan)
TsingTao = TsingTao.dropna()

close = TsingTao.Close
Volume = TsingTao.Volume

#   calculate OBV
difClose = close.diff()
difClose[0] = 0
OBV = (((difClose >= 0) * 2 - 1) * Volume).cumsum()
OBV.name = 'OBV'
#   print(OBV.head())
#   print(OBV.describe())

#   moving OBV, period == 9
smOBV = smaCal(OBV, 9)
#   print(smOBV.tail())

#   adjust OBV
AdjOBV = ((close - TsingTao.Low) - (TsingTao.High - close)) / (TsingTao.High - TsingTao.Low) * Volume
AdjOBV.name = 'AdjOBV'
#   print(AdjOBV.head())

AdjOBVd = AdjOBV.cumsum()
AdjOBVd.name = 'AdjOBVd'
#   print(AdjOBVd.describe())

'''
#   plot
ax1 = plt.subplot(3, 1, 1)
close.plot(title='Close Price of TsingTao Bear')
plt.xticks(close.index[1:3], '')
plt.xlabel('')

ax2 = plt.subplot(3, 1, 2)
OBV.plot(label='OBV', title='OBV of TsingTao Bear')
smOBV.plot(label='smOBV', linestyle='-.', color='r')
plt.legend(loc='best')
plt.xticks(close.index[1:3], '')
plt.xlabel('')

ax3 = plt.subplot(3, 1, 3)
AdjOBVd.plot(title='Volume Accumulation of TsingTao Bear')
for ax in ax1, ax2, ax3:
    ax.grid(True)

plt.show()
'''

OBVtrade = trade(OBV, close)
#   print(OBVtrade.head())

ret = OBVtrade.ret
tradeRet = OBVtrade.tradeRet
ret.name = 'BuyAndHold'
tradeRet.name = 'OBVTrade'

'''
#   plot()
(1 + ret).cumprod().plot(label='ret', linestyle='dashed')
(1 + tradeRet).cumprod().plot(label='tradeRet')
plt.title('Performance of OBV Strategy')
plt.legend(loc='best')
plt.show()
'''

OBVtest = backtest(ret, tradeRet)
#   print(OBVtest)

smOBVtrade = trade(smOBV, close)
#   print(smOBVtrade.head())

ret = smOBVtrade.ret
ret.name = 'BuyAndHold'
smtradeRet = smOBVtrade.tradeRet

'''
#   plot()
(1 + ret).cumprod().plot(label='ret', linestyle='dashed')
(1 + tradeRet).cumprod().plot(label='tradeRet')
plt.title('Performance of Simple OBV Strategy')
plt.legend(loc='best')
plt.show()
'''







