import pandas as pd
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import mpl_finance
import candle
import plotplus
import Average
from Average import smaCal
import ffn

matplotlib.use('Tkagg')

def trade(obv, price):
    signal = (2 * (obv.diff() > 0) - 1)[1:]
    ret = ffn.to_returns(price)[1:]
    ret.name = 'ret'
    tradeRet = ret * signal.shift(1)
    tradeRet.name = 'tradeRet'
    Returns = pd.merge(pd.DataFrame(ret), pd.DataFrame(tradeRet),
                      left_index=True, right_index=True).dropna()
    return Returns

def backtest(ret, tradeRet):
    def performance(x):
        winpct = len(x[x > 0]) / len(x[x != 0])
        annRet = (1 + x).cumprod()[-1] ** (245 / len(x)) - 1
        sharpe = ffn.calc_risk_return_ratio(x)
        maxDD = ffn.calc_max_drawdown((1 + x).cumprod())
        perfo = pd.Series([winpct, annRet, sharpe, maxDD],
                          index=['win rate', 'annualized return', 'sharpe ratio', 'maximum drawdown'])
        return perfo
    BuyAndHold = performance(ret)
    OBVTrade = performance(tradeRet)
    return pd.DataFrame({ret.name: BuyAndHold, tradeRet.name: OBVTrade})












