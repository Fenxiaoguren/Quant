def momentum(price, period):
    lagPrice = price.shift(period)
    momen = price - lagPrice
    momen = momen.dropna()
    return momen