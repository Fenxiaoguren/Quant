import  pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import candle
import plotplus

def upbreak(tsLine, tsRefLine):
    n = min(len(tsLine), len(tsRefLine))
    tsLine = tsLine[-n:]
    tsRefLine = tsRefLine[-n:]
    signal = pd.Series(0, index=tsLine.index)
    for i in range(1, len(tsLine)):
        if all([tsLine[i] > tsRefLine[i], tsLine[i - 1] < tsRefLine[i - 1]]):
            signal[i] = 1
    return signal

def downbreak(tsLine, tsRefLine):
    n = min(len(tsLine), len(tsRefLine))
    tsLine = tsLine[-n:]
    tsRefLine = tsRefLine[-n:]
    signal = pd.Series(0, index=tsLine.index)
    for i in range(1, len(tsLine)):
        if all([tsLine[i] < tsRefLine[i], tsLine[i - 1] > tsRefLine[i - 1]]):
            signal[i] = 1
    return signal


def bbands(tsPrice, period=20, times=2):
    upBBand = pd.Series(0.0, index=tsPrice.index)
    midBBand = pd.Series(0.0, index=tsPrice.index)
    downBBand = pd.Series(0.0, index=tsPrice.index)
    sigma = pd.Series(0.0, index=tsPrice.index)
    for i in range(period - 1, len(tsPrice)):
        midBBand[i] = np.nanmean(tsPrice[(i + 1 - period): (i + 1)])
        sigma[i] = np.nanstd(tsPrice[(i + 1 - period): (i + 1)])
        upBBand[i] = midBBand[i] + times * sigma[i]
        downBBand[i] = midBBand[i] - times * sigma[i]
    BBands = pd.DataFrame({'upBBand': upBBand[(period - 1):],
                           'midBBand': midBBand[(period - 1):],
                           'downBBand': downBBand[(period - 1):],
                           'sigma': sigma[(period - 1):]})
    return BBands

def CalBollRisk(tsPrice, multiplier):
    k = len(multiplier)
    overUp = []
    belowDown = []
    BollRisk = []
    for i in range(k):
        BBands = bbands(tsPrice, 20, multiplier[i])
        a = 0
        b = 0
        for j in range(len(BBands)):
            tsPrice = tsPrice[-len(BBands):]
            if tsPrice[j] > BBands.upBBand[j]:
                a += 1
            elif tsPrice[j] < BBands.downBBand[j]:
                b += 1
        overUp.append(a)
        belowDown.append(b)
        BollRisk.append(100 * (a + b) / len(tsPrice))
    return BollRisk

def perform(tsPrice, tsTradSig):
    ret = tsPrice / tsPrice.shift(1) - 1
    tradRet = (ret * tsTradSig).dropna()
    ret = ret[-len(tradRet):]
    winRate = [len(ret[ret > 0]) / len(ret[ret != 0]),
               len(tradRet[tradRet > 0]) / len(tradRet[tradRet != 0])]
    meanRate = [np.mean(ret[ret > 0]), np.mean(tradRet[tradRet > 0])]
    meanLoss = [np.mean(ret[ret < 0]), np.mean(tradRet[tradRet < 0])]
    Performance = pd.DataFrame({'winRate': winRate,
                                'meanRate': meanRate,
                                'meanLoss': meanLoss})
    Performance.index = ['Stock', 'Trade']
    return Performance

