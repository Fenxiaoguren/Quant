import pandas as pd
import numpy as np

def rsi(price, period=6):
    clprcChange = price - price.shift(1)
    clprcChange = clprcChange.dropna()
    indexprc = clprcChange.index
    upPrc = pd.Series(0, index=indexprc)
    upPrc[clprcChange > 0] = clprcChange[clprcChange > 0]
    downPrc = pd.Series(0, index=indexprc)
    downPrc[clprcChange < 0] = -clprcChange[clprcChange < 0]

    rsidata = pd.concat([price, clprcChange, upPrc, downPrc], axis=1)
    rsidata.columns = ['price', 'PrcChange', 'upPrc', 'downPrc']
    rsidata = rsidata.dropna()

    SMUP = []
    SMDOWN = []
    for i in range(period, len(upPrc) + 1):
        SMUP.append(np.mean(upPrc.values[(i - period): i], dtype=np.float64))
        SMDOWN.append(np.mean(downPrc.values[(i - period): i], dtype=np.float64))
    rsi = [100 * SMUP[i] / (SMUP[i] + SMDOWN[i]) for i in range(0, len(SMUP))]

    indexRsi = indexprc[(period - 1):]
    rsi = pd.Series(rsi, index=indexRsi)
    return rsi

