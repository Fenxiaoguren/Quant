import pandas as pd
import matplotlib.pyplot as plt
import plotplus
import numpy as np
from matplotlib.dates import DateFormatter, WeekdayLocator, DayLocator, MONDAY, date2num
from mpl_finance import candlestick_ohlc

def candleVolume(seriesData, candletitle='a', bartitle=''):
    Date = [date2num(date) for date in seriesData.index]
    seriesData.index = list(range(len(Date)))
    seriesData['Date'] = Date
    listData = zip(seriesData.Date, seriesData.Open,
                   seriesData.High, seriesData.Low, seriesData.Close)
    ax1 = plt.subplot(211)
    ax2 = plt.subplot(212)
    for ax in ax1, ax2:
        mondays = WeekdayLocator(MONDAY)
        weekFormatter = DateFormatter('%m/%d/%Y')
        ax.xaxis.set_major_locator(mondays)
        ax.xaxis.set_minor_locator(DayLocator())
        ax.xaxis.set_minor_formatter(weekFormatter)
        ax.grid(True)
    ax1.set_ylim(seriesData.Low.min() - 2, seriesData.High.max() + 2)
    ax1.set_ylabel('Candle Chart & Close Price')
    candlestick_ohlc(ax1, listData, width=0.7, colorup='r', colordown='g')
    plt.setp(plt.gca().get_xticklabels(),
             rotation=20, horizontalalignment='center')
    ax1.autoscale_view()
    ax1.set_title(candletitle)

    ax1.plot(seriesData.Date, seriesData.Close,
             color='black', label='Close Price')
    ax1.legend(loc='best')

    ax2.set_ylabel('Trading Volume')
    ax2.set_ylim(0, seriesData.Volume.max() * 3)
    ax2.bar(np.array(Date)[np.array(seriesData.Close >= seriesData.Open)],
            height=seriesData.iloc[:, 4][np.array(seriesData.Close >= seriesData.Open)],
            color='r', align='center')
    ax2.bar(np.array(Date)[np.array(seriesData.Close < seriesData.Open)],
            height=seriesData.iloc[:, 4][np.array(seriesData.Close < seriesData.Open)],
            color='g', align='center')
    ax2.set_title(bartitle)
    return(plt.show())








