import  pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import candle
import plotplus
import ffn
from PriceChannel import *

#
def trade(signal, price):
    ret = ((price - price.shift(1))/ price.shift(1))[1:]
    ret.name='ret'
    signal = signal.shift(1)[1:]
    tradeRet = ret * signal
    tradeRet.name = 'tradeRet'
    Returns = pd.merge(pd.DataFrame(ret),
                       pd.DataFrame(tradeRet),
                       left_index=True,
                       right_index=True).dropna()
    return Returns

def backtest(ret, tradeRet):
    def performance(x):
        winpct = len(x[x > 0]) / len(x[x != 0])
        annRet = (1 + x).cumprod()[-1] **(245 / len(x)) -1
        sharpe = ffn.calc_risk_return_ratio(x)
        maxDD = ffn.calc_max_drawdown((1 + x).cumprod())
        perfo = pd.Series([winpct, annRet, sharpe, maxDD],
                          index=['win rate', 'annualized return', 'sharpe ratio', 'maximum drawdown'])
        return perfo
    BuyAndHold = performance(ret)
    Trade = performance(tradeRet)
    return pd.DataFrame({ret.name: BuyAndHold,
                         tradeRet.name: Trade})
def upbreak(Line, RefLine):
    signal = np.all([Line > RefLine, Line.shift(1) < RefLine.shift(1)], axis=0)
    return(pd.Series(signal[1:], index=Line.index[1:]))

def downbreak(Line, RefLine):
    signal = np.all([Line < RefLine, Line.shift(1) > RefLine.shift(1)], axis=0)
    return(pd.Series(signal[1:], index=Line.index[1:]))





