import pandas as pd
import numpy as np


def smaCal(tsPrice, k):
    Sma = pd.Series(0.0, index=tsPrice.index)
    for i in range(k - 1, len(tsPrice)):
        Sma[i] = sum(tsPrice[(i - k + 1): (i + 1)]) / k
    return Sma

def wmaCal(tsPrice, weight):
    k = len(weight)
    arrWeight = np.array(weight)
    Wma = pd.Series(0.0, index=tsPrice.index)
    for i in range(k - 1, len(tsPrice.index)):
        Wma[i] = sum(arrWeight * tsPrice[(i - k + 1): (i + 1)])
    return Wma

def ewmaCal(tsPrice, period=5, exponetial=0.2):
    Ewma = pd.Series(0.0, index=tsPrice.index)
    Ewma[period - 1] = np.mean(tsPrice[0: period])
    for i in range(period, len(tsPrice)):
        Ewma[i] = exponetial * tsPrice[i] + (1 - exponetial) * Ewma[i - 1]
    return Ewma





