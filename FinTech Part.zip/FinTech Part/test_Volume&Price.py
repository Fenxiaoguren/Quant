import  pandas as pd
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import candle
import plotplus
import ffn
from candleVolume import *

#   Prevent Error:
#   Matplotlib is currently using agg, which is a non-GUI backend, so cannot show the figure.
matplotlib.use('Tkagg')

#   analyse the relationship between volume and price

CJSecurities = pd.read_csv('CJSecurities.csv', index_col='Date')
CJSecurities = CJSecurities.iloc[:, 1:]
CJSecurities.index = pd.to_datetime(CJSecurities.index)
#   print(CJSecurities.head())

CJSecurities2014 = CJSecurities['2014-01-01': '2014-12-31']
'''
print(candleVolume(CJSecurities2014, 'Candle Chart of Changjiang Securities in 2014',
                    'Trading Volume of Changjiang Securities in 2014'))
'''


close = CJSecurities.Close
#   print(close.describe())

#   adjust the close price data
BreakCLose = np.ceil(close / 2) * 2
BreakCLose.name = 'BreakClose'
#   print(pd.DataFrame({'BreakClose': BreakCLose, 'Close': close}).head(n=2))
#   CJSecurities = CJSecurities[CJSecurities['Volume'] != 0]
volume = CJSecurities.Volume
volume = volume.dropna()
PrcChange = close.diff()

#   print((volume))
#   print((PrcChange[1]))

#   UpVol = volume.replace(volume[PrcChange > 0], 0)
UpVol = volume
for i in range(1, len(volume)):
    for j in range(1, len(volume)):
        if PrcChange[j] > 0:
            UpVol[i] = volume[j]
UpVol[0] = 0

#   DownVol = volume.replace(volume[PrcChange <= 0], 0)
DownVol = volume
for i in range(1, len(volume)):
    for j in range(1, len(volume)):
        if PrcChange[j] <= 0:
            DownVol[i] = volume[j]

DownVol[0] = 0

#   calculate the total volume in this period
def VOblock(vol):
    return([np.sum(vol[BreakCLose == x]) for x in range (6, 22, 2)])

cumUpVol = VOblock(UpVol)
#   print(cumUpVol)
cumDownVol = VOblock(DownVol)
#   print(cumDownVol)
ALLVol = np.array([cumUpVol, cumDownVol]).transpose()
#   print(ALLVol)

#   plot
'''
fig, ax = plt.subplots()
ax1 = ax.twiny()
ax.plot(close)
ax.set_title('Cumulative Trading Volume in Different Price Ranges')
ax.set_ylim(4, 20)
ax.set_xlabel('Time')
plt.setp(ax.get_xticklabels(), rotation=20, horizontalalignment='center')
ax1.barh(y=range(4, 20, 2), width=ALLVol[:, 0],
         height=2, color='g', alpha=0.2)
ax1.barh(y=range(4, 20, 2), width=ALLVol[:, 1],
         height=2, left=ALLVol[:, 0], color='r', alpha=0.2)
plt.show()
'''

#   Volume & MA Strategy
volume = CJSecurities.Volume
#   VolSMA5 = pd.rolling_apply(volume, 5, np.mean)
VolSMA5 = CJSecurities['Volume'].rolling(5).mean()

#   VolSMA10 = pd.rolling_apply(volume, 10, np.mean)
VolSMA10 = CJSecurities['Volume'].rolling(10).mean()
VolSMA = ((VolSMA5 + VolSMA10) / 2).dropna()
#   print(VolSMA.head(n=3))

VolSignal = (volume[-len(VolSMA):] > VolSMA) * 1
VolSignal[VolSignal == 0] = -1
#   print(VolSignal.head())

close = CJSecurities.Close
PrcSMA5 = CJSecurities['Close'].rolling(5).mean()
PrcSMA20 = CJSecurities['Close'].rolling(20).mean()

#   ---2023-03-30---
#   UpSMA == 0 AND DownSMA == 0

def upbreak(Line, RefLine):
    signal = np.all([Line > RefLine, Line.shift(1) < RefLine.shift(1)], axis=0)
    return pd.Series(signal[1:], index=Line.index[1:])

def downbreak(Line, RefLine):
    signal = np.all([Line < RefLine, Line.shift(1) > RefLine.shift(1)], axis=0)
    return pd.Series(signal[1:], index=Line.index[1:])


UpSMA = upbreak(PrcSMA5[-len(PrcSMA20):], PrcSMA20) * 1
print(UpSMA)
DownSMA = downbreak(PrcSMA5[-len(PrcSMA20):], PrcSMA20) * 1
print(DownSMA)
SMAsignal = UpSMA - DownSMA
print(SMAsignal)
VolSignal = VolSignal[-len(SMAsignal):]
signal = VolSignal + SMAsignal
#   print(signal.describe())    #   not same with codes in the book

trade = signal.replace([2, -2, 1, -1, 0], [1, -1, 0, 0, 0])
trade = trade.shift(1)[1:]
print(trade.head())













































