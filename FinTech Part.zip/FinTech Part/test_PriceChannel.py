import  pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import candle
import plotplus
from PriceChannel import *


#   1.  Donchian Channel

#   Take ChinaUnicom as an example
ChinaUnicom = pd.read_csv('ChinaUnicom.csv')
ChinaUnicom.index = ChinaUnicom.iloc[:, 1]
ChinaUnicom.index = pd.to_datetime(ChinaUnicom.index, format='%Y-%m-%d')
ChinaUnicom = ChinaUnicom.iloc[:, 2:]

ChinaUnicom13 = ChinaUnicom['2013-01-01': '2013-12-31']

Close = ChinaUnicom.Close
High = ChinaUnicom.High
Low = ChinaUnicom.Low

upboundDC = pd.Series(0.0, index=Close.index)
downboundDC = pd.Series(0.0, index=Close.index)
midboundDC = (upboundDC + downboundDC) / 2

for i in range(20, len(Close)):
    upboundDC[i] = max(High[(i - 20): i])
    downboundDC[i] = min(Low[(i - 20): i])
    midboundDC[i] = (upboundDC[i] + downboundDC[i]) / 2

upboundDC = upboundDC[20:]
downboundDC = downboundDC[20:]
midboundDC = midboundDC[20:]

'''
#   plot
plt.plot(Close['2013'], label='CLose', color='k')
plt.plot(upboundDC['2013'], label='upboundDC', color='b', linestyle='dashed')
plt.plot(downboundDC['2013'], label='downboundDC', color='r', linestyle='-.')
plt.plot(midboundDC['2013'], label='midboundDC', color='g', linestyle='dashed')
plt.title('Dochian Channel of ChinaUnicom in 2013')
plt.ylim(2.9, 3.9)
plt.legend(loc='best')

#   K-Line
upDownDC = pd.DataFrame({'upboundDC': upboundDC,
                          'downboundDC': downboundDC,
                          'midboundDC': midboundDC})

upDownDC13 = upDownDC['2013-01-01': '2013-12-31']
candle.candleLinePlots(candleData=ChinaUnicom13,
                       splitFigures=False,
                       candleTitle='K-Line and Dochian Channel of ChinaUnicom in 2013',
                       Data=upDownDC13)

plt.show()
'''

#   DC strategy
UpBreak = upbreak(Close[upboundDC.index[0]:], upboundDC)
DownBreak = downbreak(Close[downboundDC.index[0]:], downboundDC)

BreakSig = UpBreak - DownBreak
tradeSig = BreakSig.shift(1)
ret = Close / Close.shift(1) - 1
tradeRet = (ret * tradeSig).dropna()
tradeRet[tradeRet == -0] = 0
winRate = len(tradeRet[tradeRet > 0]) / len(tradeRet[tradeRet != 0])

#   print(winRate)  #   0.45614035087719296

#   2. Bollinger Bands: BBands

UnicomBBands = bbands(Close, 20, 2)
#   print(UnicomBBands.head())
upDownBB = UnicomBBands[['downBBand', 'upBBand']]
upDownBB13 = upDownBB['2013-01-01': '2013-12-31']
'''
candle.candleLinePlots(candleData=ChinaUnicom13,
                       splitFigures=False,
                       candleTitle='Bollinger Bands of ChinaUnicom in 2013',
                       Data=upDownBB13)
'''

#   2.1 Compare risk of CHhinaUnicom in 2010, 2011, 2012 and 2013 (bollinger)

multiplier = [1, 1.65, 1.96, 2, 2.58]

price2010 = Close['2010-01-01': '2010-12-31']
#   print(CalBollRisk(price2010, multiplier))
price2011 = Close['2011-01-01': '2011-12-31']
price2012 = Close['2012-01-01': '2012-12-31']
price2013 = Close['2013-01-01': '2013-12-31']

#   2.2 Strategy1:  when stock price goes up through the band(below), short it
#                   when stock price goes down through the band(above), long it

#   trade after 2 days when the signal appears
BBands = bbands(Close, 20, 2)
upbreakBB1 = upbreak(Close, BBands.upBBand)
downbreakBB1 = downbreak(Close, BBands.downBBand)
upBBSig1 = -upbreakBB1.shift(2)
downBBSig1 = downbreakBB1.shift(2)
tradSignal1 = upBBSig1 + downBBSig1
tradSignal1[tradSignal1 == -0] = 0

#   row 1 == performance of the stock itself
#   row 2 == performance of strategy 1
Performance1 = perform(Close, tradSignal1)
#   print(Performance1)
'''
        winRate  meanRate  meanLoss
Stock  0.458525  0.013320 -0.012599
Trade  0.557692  0.014709 -0.011710
'''

#   2.3 Strategy2:  when stock price goes up through the band(above), short it
#                   when stock price goes down through the band(below), long it
BBands = bbands(Close, 20, 2)
#   different from last strategy
upbreakBB2 = upbreak(Close, BBands.downBBand)
downbreakBB2 = downbreak(Close, BBands.upBBand)
upBBSig2 = upbreakBB2.shift(2)
downBBSig2 = -downbreakBB2.shift(2)
tradSignal2 = upBBSig2 + downBBSig2
tradSignal2[tradSignal2 == -0] = 0

#   row 1 == performance of the stock itself
#   row 2 == performance of strategy 2
Performance2 = perform(Close, tradSignal2)
#   print(Performance2)

'''
        winRate  meanRate  meanLoss
Stock  0.458525  0.013320 -0.012599
Trade  0.529412  0.014584 -0.010517
'''







